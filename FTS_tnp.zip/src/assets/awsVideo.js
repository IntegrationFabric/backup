            $('#start').click(function() {
                var streamName = "videostream_aws";

                // Step 1: Configure SDK Clients
                var options = {
                    accessKeyId: "AKIAJH374IDBNXURL2AA",
                    secretAccessKey: "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",
                    sessionToken: undefined,
                    region: "us-east-1",
                    endpoint: undefined
                }
                var kinesisVideo = new AWS.KinesisVideo(options);
                var kinesisVideoArchivedContent = new AWS.KinesisVideoArchivedMedia(options);

                // Step 2: Get a data endpoint for the stream
                console.log('Fetching data endpoint');
                kinesisVideo.getDataEndpoint({
                    StreamName: streamName,
                    APIName: "GET_HLS_STREAMING_SESSION_URL"
                }, function(err, response) {
                    if (err) { return console.error(err); }
                    console.log('Data endpoint: ' + response.DataEndpoint);
                    kinesisVideoArchivedContent.endpoint = new AWS.Endpoint(response.DataEndpoint);

                    // Step 3: Get an HLS Streaming Session URL
                    console.log('Fetching HLS Streaming Session URL');
                    kinesisVideoArchivedContent.getHLSStreamingSessionURL({
                        StreamName: streamName,
                        PlaybackMode: "LIVE",
                        HLSFragmentSelector: {
                            FragmentSelectorType: "SERVER_TIMESTAMP",
                            TimestampRange: "LIVE" === "LIVE" ? undefined : {
//                                StartTimestamp: new Date($('#startTimestamp').val()),
//                                EndTimestamp: new Date($('#endTimestamp').val())
                            }
                        },
                        DiscontinuityMode: "ALWAYS",
                        MaxMediaPlaylistFragmentResults: parseInt(undefined),
                        Expires: parseInt(undefined)
                    }, function(err, response) {
                        if (err) { return console.error(err); }
                        console.log('HLS Streaming Session URL: ' + response.HLSStreamingSessionURL);

                        // Step 4: Give the URL to the video player.
                        var playerName = "VideoJS";
                        if (playerName === 'VideoJS') {
                            var playerElement = document.getElementById('videojs');
                            console.log('Created VideoJS Player');
                            playerElement.src = response.HLSStreamingSessionURL;
                            playerElement.type = 'application/x-mpegURL';
                            console.log('Set player source');

                            playerElement.play();
                            console.log('Starting playback');
                        } 
                    });
                });
            });

            // Read/Write all of the fields to/from localStorage so that fields are not lost on refresh.
            [
                'player',
                'region',
                'accessKeyId',
                'secretAccessKey',
                'sessionToken',
                'endpoint',
                'streamName',
                'playbackMode',
                'startTimestamp',
                'endTimestamp',
                'fragmentSelectorType',
                'discontinuityMode',
                'maxMediaPlaylistFragmentResults',
                'expires'
            ].forEach(function(field) {
                var id = "#" + field;

                // Read field from localStorage
                try {
                    var localStorageValue = localStorage.getItem(field);
                    if (localStorageValue) { $(id).val(localStorageValue); }
                } catch (e) { /* Don't use localStorage */ }

                // Write field to localstorage on change event
                $(id).change(function() {
                    try {
                        localStorage.setItem(field, $(id).val());
                    } catch (e) { /* Don't use localStorage */ }
                });
            });
            // Initially hide the player elements

            
        console.log("Page loaded")