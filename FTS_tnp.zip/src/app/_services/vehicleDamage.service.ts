import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
 
@Injectable({ providedIn: 'root' })
export class VehicleDamageService {
    private imageFlag = new Subject<any>();
 
    setImageFlag(data: boolean) {
        this.imageFlag.next(data);
    }
 
    clearImageFlag() {
        this.imageFlag.next();
    }
 
    getImageFlag(): Observable<boolean> {
        return this.imageFlag.asObservable();
    }
}