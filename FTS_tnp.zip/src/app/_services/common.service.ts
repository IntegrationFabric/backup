import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
 
@Injectable({ providedIn: 'root' })
export class CommonService {
    private subject = new Subject<any>();
 
    sendMenuName(message: string) {
        this.subject.next({ text: message });
    }
 
    clearMenu() {
        this.subject.next();
    }
 
    getMenuName(): Observable<any> {
        return this.subject.asObservable();
    }
}