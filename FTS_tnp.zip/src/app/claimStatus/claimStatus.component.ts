import { Component, OnInit, OnDestroy } from "@angular/core";
import { CommonService } from '../_services/common.service';

@Component({
    selector: "claimStatus",
    templateUrl: "./claimStatus.component.html",
    styleUrls: ['./claimStatus.component.css']
})
export class ClaimStatusComponent implements OnInit, OnDestroy {
    constructor(private commonService: CommonService) {
        this.commonService.sendMenuName('Claim Status');
    }

    public setMenuNameOnNextAndBack(data: any): void {
        this.commonService.sendMenuName(data);
    }

    ngOnDestroy() {
        this.setMenuNameOnNextAndBack('Touch&Paid');
    }

    ngOnInit() { }
}
