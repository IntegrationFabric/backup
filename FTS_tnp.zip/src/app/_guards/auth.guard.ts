import { Injectable } from "@angular/core";
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from "@angular/router";
import { Observable } from "rxjs";
import { map, take } from "rxjs/operators";
import { AuthenticationService } from "../_services";

@Injectable({ providedIn: "root" })
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> {
    return this.authenticationService.isLoggedIn.pipe(
      take(1),
      map((isLoggedIn: boolean) => {
        const currentUser = this.authenticationService.currentUserValue;
        if (isLoggedIn && currentUser) {
          // check if route is restricted by role
          if (
            next.data.roles &&
            next.data.roles.indexOf(currentUser.role) === -1
          ) {
            // role not authorised so redirect to home page
            this.router.navigate(["/"]);
            return false;
          }

          // authorised so return true
          return true;
        }
        // not logged in so redirect to login page with the return url
        this.router.navigate(["/login"], {
          queryParams: { returnUrl: state.url }
        });
        return false;
      })
    );
  }
}
