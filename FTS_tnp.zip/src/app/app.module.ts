import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { FlexLayoutModule } from "@angular/flex-layout";

import { ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

// used to create fake backend
import { fakeBackendProvider } from "./_helpers";

import { JwtInterceptor, ErrorInterceptor } from "./_helpers";

// Material Design
import { MyMaterialModule } from "./material.module";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { FooterComponent } from "./shared/footer/footer.component";
import { LoginComponent } from "./login-component/login-component.component";
import { RegistrationComponent } from "./registration-component/registration-component.component";
import { WebcamModule } from "ngx-webcam";
import { InsuranceComponent } from "./insuranceSteps/insurance.component";
import { CameraComponent } from "./insuranceSteps/camera/camera.component";
import { LocationComponent } from "./insuranceSteps/location/location.component";
import { HomeComponent } from "../app/home";
import { AdminComponent } from "./admin";
import { ClaimStatusComponent } from "./claimStatus/claimStatus.component";
import { DroneVideoPageComponent } from "./admin/modalComponent/droneVideoPage.component";
import { VideoModalComponent } from "./admin/videoModal/videoModal.component";

// videogular
import {VgCoreModule} from 'videogular2/core';
import {VgControlsModule} from 'videogular2/controls';
import {VgOverlayPlayModule} from 'videogular2/overlay-play';
import {VgBufferingModule} from 'videogular2/buffering';
import { VgStreamingModule } from "videogular2/streaming";
@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    LoginComponent,
    RegistrationComponent,
    InsuranceComponent,
    CameraComponent,
    LocationComponent,
    HomeComponent,
    AdminComponent,
    ClaimStatusComponent,
    DroneVideoPageComponent,
    VideoModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MyMaterialModule,
    FlexLayoutModule,
    WebcamModule,
    ReactiveFormsModule,
    HttpClientModule,
    VgCoreModule,
    VgControlsModule,
    VgOverlayPlayModule,
    VgBufferingModule,
    VgStreamingModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

    // provider used to create fake backend
    fakeBackendProvider
  ],
  bootstrap: [AppComponent],
  entryComponents: [VideoModalComponent]
})
export class AppModule {}
