import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "./_guards";

import { LoginComponent } from "./login-component/login-component.component";
import { HomeComponent } from "../app/home";
import { RegistrationComponent } from "./registration-component/registration-component.component";
import { InsuranceComponent } from "./insuranceSteps/insurance.component";
import { AdminComponent } from "./admin";
import { Role } from "./_models";
import { ClaimStatusComponent } from "./claimStatus/claimStatus.component";
import {DroneVideoPageComponent  } from "./admin/modalComponent/droneVideoPage.component"
const routes: Routes = [
  {
    path: "",
    component: HomeComponent,
    canActivate: [AuthGuard],
  },
  {
    path: "admin",
    component: AdminComponent,
    canActivate: [AuthGuard],
    data: { roles: [Role.Admin] }
  },
  {
    path: "login",
    component: LoginComponent
  },
  // otherwise redirect to home
  { path: "register", component: RegistrationComponent },
  {
    path: "insurance",
    component: InsuranceComponent,
    canActivate: [AuthGuard],
    data: { roles: [Role.User] }
  },
  {
    path: "claimstatus",
    component:ClaimStatusComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "dronevideopage",
    component: DroneVideoPageComponent,
    canActivate: [AuthGuard]
  },
  { path: "**", redirectTo: "" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
