import { Component, OnInit, OnDestroy, Output, EventEmitter } from "@angular/core";
import { WebcamImage } from "ngx-webcam";
import { User } from "../_models";
import { UserService, AuthenticationService, VehicleDamageService, CommonService } from "../_services";
import { first } from "rxjs/operators";
import {MatSnackBar} from '@angular/material';
import { Subscription } from "rxjs";
import {HttpClientModule, HttpClient, HttpRequest, HttpResponse, HttpEventType} from '@angular/common/http';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: "insurance",
  templateUrl: "./insurance.component.html",
  styleUrls: ["./insurance.component.css"]
})
export class InsuranceComponent implements OnInit, OnDestroy {
  currentUser: User;
  userFromApi: User;
  imageFlag: boolean = true;
  subscription: Subscription;
  percentDone: number;
  uploadSuccess: boolean;
  vehicleImage: any;
  imgFile: File[];
  selectedFile: File = null;
  isResponseOk: boolean = false;
  color: any;
      location
         carCheck;
      carDamageCheck
      make
            model ;
      typeOfVehicle;
      numberPlate;
      region;
      severity ;
  @Output() event = new EventEmitter();
  public image: any;
  
  constructor(
    private commonService: CommonService,
    private userService: UserService,
    private authenticationService: AuthenticationService,
    public snackBar: MatSnackBar,
    private vehicleDamageService: VehicleDamageService,
    private http: HttpClient
  ) {
    this.currentUser = this.authenticationService.currentUserValue;
    this.commonService.sendMenuName("Claim Summary");
    this.subscription = this.vehicleDamageService.getImageFlag().subscribe(data => {
      this.imageFlag = data;
    });
  }

  name = 'Angular 4';
  url = [];
  

  public setMenuNameOnNextAndBack(data: any): void {
    console.log("img file: ",this.imgFile);
    this.commonService.sendMenuName(data);
  }
  // latest snapshot
  public webcamImage: WebcamImage = null;
  onSelectFile(event: any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event: any) => { // called once readAsDataURL is completed
        this.url = event.target.result;
      }
    }
  }
  handleImage(webcamImage: WebcamImage) {
    this.imageFlag = false;
    setTimeout(() => {
      this.webcamImage = webcamImage; 
    }, 1500);
    
  }

  ngOnDestroy() {
    this.setMenuNameOnNextAndBack("Touch&Paid");
  }

  ngOnInit() {
    this.userService
      .getById(this.currentUser.id)
      .pipe(first())
      .subscribe(user => {
        this.userFromApi = user;
      });
  }

  step = 0;

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }
  public onFileSelected(event) {
    this.selectedFile = <File>event.target.files[0];
    if (this.selectedFile) {
      return this.upload();
    }
  }
/**
   * Upload image to server and receive image object
   */
  upload() {
    const fd = new FormData();
    console.log("this.selectedFile", this.selectedFile);
    console.log("this.selectedFile.name", this.selectedFile.name);
    fd.append('file', this.selectedFile, this.selectedFile.name);
    this.http.post('http://127.0.0.1:8080/assessment', fd).subscribe((res: any) => {
      console.log("Reponse: ", res);
      this.openSnackBar("Please tap on next to continue.","Success");
      this.isResponseOk = true;
      this.color = res.color;
      this.location = res.location;
      this.carCheck = res.gate1_result;
      this.carDamageCheck = res.gate2_result;
      this.make = res.make;
      this.model = res.model;
      this.typeOfVehicle = res.typeOfvehicle;
      this.numberPlate = res.numberplate;
      this.region = res.region;
      this.severity = res.severity;
      this.event.emit(this.image);
    }, (err: any) => {
      // Show error message or make something.
    });
  }
}
