import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from './_services';
import { CommonService } from './_services/common.service'
import { Subscription, Observable } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'touchlessClaim';
  menuName = 'Touch&Paid';
  subscription: Subscription;
  isLoggedIn$: Observable<boolean>;
  constructor(
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
    private router: Router){
      this.subscription = this.commonService.getMenuName().subscribe(data => {
        this.menuName = data.text;
      });
    }

    ngOnInit(){
      this.isLoggedIn$ = this.authenticationService.isLoggedIn;
    }

  logout(){
    // reset login status
  this.authenticationService.logout();
  this.router.navigate(["/login"]);
  }
}
