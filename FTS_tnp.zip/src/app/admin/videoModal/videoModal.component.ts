import { Component, OnInit, ViewChild } from "@angular/core";
import { BitrateOption, VgAPI } from "videogular2/core";
import { timer } from "rxjs";
import { Subscription } from "rxjs";
import { IDRMLicenseServer } from "videogular2/streaming";
import { VgDASH } from "videogular2/src/streaming/vg-dash/vg-dash";
import { VgHLS } from "videogular2/src/streaming/vg-hls/vg-hls";
import { MatSnackBar } from "@angular/material";

var streamName = "videostream_aws";
declare var AWS: any;

export interface IMediaStream {
  type: "vod" | "dash" | "hls";
  source: string;
  label: string;
  token?: string;
  licenseServers?: IDRMLicenseServer;
}

@Component({
  selector: "videoModal",
  templateUrl: "VideoModal.component.html"
})
export class VideoModalComponent implements OnInit {
  currentStreamSource: any;
  @ViewChild(VgDASH) vgDash: VgDASH;
  @ViewChild(VgHLS) vgHls: VgHLS;

  currentStream: IMediaStream;
  api: VgAPI;

  bitrates: BitrateOption[];

  streams: IMediaStream[] = [
    {
      type: "hls",
      label: "HLS: Streaming",
      source: ""
    }
  ];

  constructor(public snackBar: MatSnackBar) {
    // Step 1: Configure SDK Clients
    var options = {
      accessKeyId: "AKIAJH374IDBNXURL2AA",
      secretAccessKey: "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",
      sessionToken: undefined,
      region: "us-east-1",
      endpoint: undefined
    };
    var kinesisVideo = new AWS.KinesisVideo(options);
    var kinesisVideoArchivedContent = new AWS.KinesisVideoArchivedMedia(
      options
    );

    // Step 2: Get a data endpoint for the stream
    console.log("Fetching data endpoint");
    kinesisVideo.getDataEndpoint(
      {
        StreamName: streamName,
        APIName: "GET_HLS_STREAMING_SESSION_URL"
      },
      function(err, response) {
        if (err) {
          return console.error(err);
        }
        console.log("Data endpoint: " + response.DataEndpoint);
        kinesisVideoArchivedContent.endpoint = new AWS.Endpoint(
          response.DataEndpoint
        );

        // Step 3: Get an HLS Streaming Session URL
        console.log("Fetching HLS Streaming Session URL");
        kinesisVideoArchivedContent.getHLSStreamingSessionURL(
          {
            StreamName: streamName,
            PlaybackMode: "LIVE",
            HLSFragmentSelector: {
              FragmentSelectorType: "SERVER_TIMESTAMP",
              TimestampRange:
                "LIVE" === "LIVE"
                  ? undefined
                  : {
                      //                                StartTimestamp: new Date($('#startTimestamp').val()),
                      //                                EndTimestamp: new Date($('#endTimestamp').val())
                    }
            },
            DiscontinuityMode: "ALWAYS",
            MaxMediaPlaylistFragmentResults: parseInt(undefined),
            Expires: parseInt(undefined)
          },
          function(err, response) {
            if (err) {
              return console.error(err);
            }
            console.log(
              "HLS Streaming Session URL: " + response.HLSStreamingSessionURL
            );

            // Step 4: Give the URL to the video player.
            this.currentStreamSource = response.HLSStreamingSessionURL;
          }
        );
      }
    );
  }
  onPlayerReady(api: VgAPI) {
      setTimeout(() => {
        this.api = api;   
        console.log("Player Initialized");   
      }, 3500);
    
  }
  ngOnInit() {
        this.streams[0].source = this.currentStreamSource;
        this.currentStream = this.streams[0];
  }

  setBitrate(option: BitrateOption) {
    switch (this.currentStream.type) {
      case "dash":
        this.vgDash.setBitrate(option);
        break;

      case "hls":
        this.vgHls.setBitrate(option);
        break;
    }
  }

  onClickStream(stream: IMediaStream) {
    this.api.pause();
    this.bitrates = null;
  }
  startPlayer(){
    this.streams[0].source = this.currentStreamSource;
        this.currentStream = this.streams[0];
  }
}
