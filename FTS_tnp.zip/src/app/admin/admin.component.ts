import { Component, OnInit, Inject, ViewChild, Renderer2 } from "@angular/core";

import { User } from "../_models";
import { UserService, AuthenticationService } from "../_services";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatDialog } from "@angular/material";
import { Router } from "@angular/router";
import { VideoModalComponent } from "./videoModal/videoModal.component";

export interface PeriodicElement {
  srNo: number;
  policyNumber: string;
  claimNumber: number;
  claimStatus: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    srNo: 1,
    policyNumber: "A2323423",
    claimNumber: 12344,
    claimStatus: "Closed",
    action: "Accepted"
  },
  {
    srNo: 2,
    policyNumber: "32245R78",
    claimNumber: 243622,
    claimStatus: "Active",
    action: "Pending"
  },
  {
    srNo: 3,
    policyNumber: "2470F223",
    claimNumber: 423444,
    claimStatus: "Draft",
    action: "Approved"
  }
];

@Component({ templateUrl: "admin.component.html" })
export class AdminComponent implements OnInit {
  users: User[] = [];
  currentUser: User;
  userFromApi: User;
  statusOfApproval: string;
  name: string;
  options: FormGroup;
  displayedColumns = [
    "srNo",
    "policyNumber",
    "claimNumber",
    "claimStatus",
    "action"
  ];
  dataSource = ELEMENT_DATA;
  constructor(
    private userService: UserService,
    private authenticationService: AuthenticationService,
    public dialog: MatDialog,
    private router: Router,
    private renderer: Renderer2,
    fb: FormBuilder
  ) {
    this.options = fb.group({
      color: "primary",
      fontSize: [16, Validators.min(10)]
    });
    this.currentUser = this.authenticationService.currentUserValue;
  }

  ngOnInit() {
    // this.userService.getAll().pipe(first()).subscribe(users => {
    //     this.users = users;
    // });
  }

  openDialog() {
    const dialogRef = this.dialog.open(VideoModalComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  goToVideoPage() {
    this.dataSource.find(x => x.action == "Pending").action = "Approved";
    this.router.navigate(["/dronevideopage"]);
  }
}
