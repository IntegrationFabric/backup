import { Component, OnInit, Inject, ViewChild } from '@angular/core';

import { User } from '../../_models';
import { UserService, AuthenticationService } from '../../_services';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {MatSnackBar} from '@angular/material';

@Component({selector: 'dronevideopage',
templateUrl: './droneVideoPage.component.html',
styleUrls: ['./droneVideoPage.component.css'] })
export class DroneVideoPageComponent implements OnInit {
  currentUser: User;
  userFromApi: User;

  constructor(
    private userService: UserService,
    private authenticationService: AuthenticationService,
    public snackBar: MatSnackBar
  ) {
    this.currentUser = this.authenticationService.currentUserValue;
  }

  ngOnInit() {

  }
  

}
